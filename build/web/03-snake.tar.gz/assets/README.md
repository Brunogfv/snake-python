# 🐍 Snake Deluxe - Web & Mobile Edition

Uma versão moderna, viciante e profissional do clássico jogo da cobra, desenvolvida em Python com Pygame e otimizada para navegadores e dispositivos móveis.

## 🚀 Funcionalidades Incríveis

Este não é apenas um jogo de Snake comum. Ele foi elevado ao nível "Deluxe" com mecânicas avançadas:

### 1. 💰 Economia e Customização
*   **Sistema de Ouro:** Colete ouros durante as partidas para acumular riqueza.
*   **Loja de Skins:** Desbloqueie e equipe skins exclusivas como **Neon**, **Fogo**, **Gelo** e **Realeza**.
*   **Persistência:** Seu progresso, recordes e itens comprados são salvos automaticamente.

### 2. 🎮 Modos de Jogo e Fases
*   **Modo Clássico:** Paredes são mortais.
*   **Modo Livre:** Atravesse as bordas da tela.
*   **Multiplayer Local (X1):** Desafie um amigo no mesmo teclado (Setas vs WASD).
*   **Mapas Variados:** Jogue em níveis desafiadores como **Pilares**, **Labirinto** e **Apartamento**.

### 3. 🔥 Mecânicas de Gameplay
*   **Modo Fever (Berserk):** Ative combos comendo rápido para ganhar invencibilidade e pontos em dobro.
*   **Portais (Wormholes):** Use fendas espaciais para se teletransportar estrategicamente pelo mapa.
*   **Inimigos (IA):** Enfrente outras cobras controladas pelo computador que tentam roubar sua comida. Elimine-as para ganhar bônus!

### 4. ✨ Polimento Visual e UX
*   **Juice:** Efeitos de partículas, trepidação de tela (*screen shake*) e gradientes suaves.
*   **Áudio Procedural:** Sons gerados via código, sem necessidade de arquivos externos pesados.
*   **Mobile Ready:** Controles de toque integrados (D-Pad visual) para jogar no celular.

## 🛠️ Tecnologias Utilizadas

*   **Linguagem:** Python 3
*   **Biblioteca Gráfica:** Pygame-ce
*   **Conversão Web:** Pygbag (WebAssembly)
*   **Assincronismo:** Asyncio para compatibilidade com navegadores

## 🕹️ Como Jogar

### No Computador:
*   **Setas:** Mover (P1)
*   **WASD:** Mover (P2 - Multiplayer)
*   **P:** Pausar
*   **ESC:** Menu Principal

### No Celular:
*   **D-Pad Visual:** Toque nas setas no canto da tela para mover.
*   **Menu:** Interface totalmente clicável/tocável.
*   **Pausa:** Toque no topo da tela.

---
Desenvolvido com ❤️ por [Bruno](https://github.com/Brunogfv)
